<div class="w3-bar menu-brown">
	<a href="index.php" class="w3-bar-item w3-button">Home</a>

	<a href="showProducts.php" class="w3-bar-item w3-button">View Products</a>
	<a href="newProduct.php" class="w3-bar-item w3-button">New Product</a>
	<a href="editProduct.php" class="w3-bar-item w3-button">Edit Product</a>
	<a href="deleteProduct.php" class="w3-bar-item w3-button">Delete Product</a>
</div>