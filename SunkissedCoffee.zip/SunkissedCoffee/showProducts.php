<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Sunkissed Coffee - Show Products</title>
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	<div class="container">
		<header class="w3-container w3-center header-brown">
			<h1>Sunkissed Coffee</h1>
			<h2 class="page-title">Show Products</h2>
		</header>

		<?php include "mainMenu.php"; ?>

		<div class="w3-container cream">
			<?php
				include "connectDatabase.php";

				$sql  = "SELECT p.product_id, p.name, p.price, p.stock, c.category_name ";
				$sql .= "FROM products p ";
				$sql .= "INNER JOIN categories c ";
				$sql .= "ON p.category_id = c.category_id ";
				$sql .= "ORDER BY p.product_id ";

				$result = $conn->query($sql);

				if($result->num_rows > 0){
					echo "<table class='w3-table w3-striped w3-bordered w3-card-4'>";
					echo "<tr class='dark-brown'>";
					echo "<th>Product ID</th>";
					echo "<th>Category</th>";
					echo "<th>Name</th>";
					echo "<th>Price</th>";
					echo "<th>Stock</th>";
					echo "</tr>";

					while($row = $result->fetch_assoc()){
						echo "<tr>";
						echo "<td>".$row['product_id']."</td>";
						echo "<td>".$row['category_name']."</td>";
						echo "<td>".$row['name']."</td>";
						echo "<td>$".$row['price']."</td>";
						echo "<td>".$row['stock']."</td>";
						echo "</tr>";
					}

					echo "</table>";
				}
				else{
					echo "<p>No products found.</p>";
				}

				$conn->close();
			?>
		</div>
	</div>
</body>
</html>