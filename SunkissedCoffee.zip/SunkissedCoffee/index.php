<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Sunkissed Coffee</title>
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	<div class="container">
		<header class="w3-container w3-center header-brown">
			<h1>Sunkissed Coffee</h1>
			<h2 class="page-title">Coffee Shop Ordering</h2>
		</header>

		<?php include "mainMenu.php"; ?>

		<div class="w3-container cream">
        <img src="coffee.png" alt="Sunkissed Coffee" class="coffee-img">
			<h3>Welcome to Sunkissed Coffee</h3>
			<p>
				This is a group project by Ivy Nguyen, Hailey Paul, Sameen Khan
			</p>

		</div>
	</div>
</body>
</html>