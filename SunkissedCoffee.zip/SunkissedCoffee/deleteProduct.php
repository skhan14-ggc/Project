<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Sunkissed Coffee - Delete Product</title>
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	<div class="container">
		<header class="w3-container w3-center header-brown">
        <img src="coffee.png" alt="Sunkissed Coffee" class="coffee-img">
			<h1>Sunkissed Coffee</h1>
			<h2 class="page-title">Delete Product</h2>
		</header>

		<?php include "mainMenu.php"; ?>

		<form class="w3-container cream" method="POST" action="deleteProduct.php">
			<fieldset>
				<p>
					<label>Product to Delete</label>
					<select class="w3-select w3-border" name="product_id">
						<option value="" disabled selected>Choose product</option>

						<?php
							include "connectDatabase.php";

							$sql  = "SELECT p.* ";
							$sql .= "FROM products p LEFT JOIN order_items oi ";
							$sql .= "ON p.product_id = oi.product_id ";
							$sql .= "WHERE oi.order_item_id IS NULL ";
							$sql .= "ORDER BY p.product_id ";

							$result = $conn->query($sql);

							if($result->num_rows > 0){
								while($row = $result->fetch_assoc()){
									$product_id = $row['product_id'];
									$name = $row['name'];

									echo "<option value='$product_id'>$product_id - $name</option>";
								}
							}

							$conn->close();
						?>
					</select>
				</p>

				<p>
					<b>Note:</b> Only products that have not been ordered can be deleted.
				</p>
			</fieldset>

			<br>
			<input class="w3-button w3-red" type="submit" name="submit" value="Delete Product">
		</form>

		<div class="w3-container cream">
			<?php
				if(isset($_POST['submit'])){
					if(!isset($_POST['product_id'])){
						echo "<div class='w3-pale-red w3-padding message-box'>";
						echo "You have not selected a product.<br>";
						echo "Please go back and try again.";
						echo "</div>";
						exit;
					}

					include "connectDatabase.php";

					$product_id = mysqli_real_escape_string($conn, $_POST['product_id']);

					$sql  = "DELETE ";
					$sql .= "FROM products ";
					$sql .= "WHERE product_id = '$product_id' ";

					if($conn->query($sql) === TRUE){
						echo "<div class='w3-pale-green w3-padding message-box'>";
						echo "The product was successfully deleted!<br>";
						echo "Product ID: $product_id";
						echo "</div>";
					}
					else{
						echo "<div class='w3-pale-red w3-padding message-box'>";
						echo "Error: ".$sql."<br>".$conn->error;
						echo "</div>";
					}

					$conn->close();
				}
			?>
		</div>
	</div>
</body>
</html>