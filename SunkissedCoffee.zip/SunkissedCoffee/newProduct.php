<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Sunkissed Coffee - New Product</title>
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	<div class="container">
		<header class="w3-container w3-center header-brown">
        <img src="coffee.png" alt="Sunkissed Coffee" class="coffee-img">
			<h1>Sunkissed Coffee</h1>
			<h2 class="page-title">New Product</h2>
		</header>

		<?php include "mainMenu.php"; ?>

		<form class="w3-container cream" method="POST" action="newProduct.php">
			<fieldset>
				<p>
					<label>Category</label>
					<select class="w3-select w3-border" name="category_id">
						<option value="" disabled selected>Choose category</option>

						<?php
							include "connectDatabase.php";

							$sql  = "SELECT * ";
							$sql .= "FROM categories ";
							$sql .= "ORDER BY category_name ";

							$result = $conn->query($sql);

							if($result->num_rows > 0){
								while($row = $result->fetch_assoc()){
									$category_id = $row['category_id'];
									$category_name = $row['category_name'];

									echo "<option value='$category_id'>$category_name</option>";
								}
							}

							$conn->close();
						?>
					</select>
				</p>

				<p>
					<label>Product Name</label>
					<input class="w3-input w3-border" type="text" name="name">
				</p>

				<p>
					<label>Price</label>
					<input class="w3-input w3-border" type="text" name="price">
				</p>

				<p>
					<label>Stock</label>
					<input class="w3-input w3-border" type="text" name="stock">
				</p>
			</fieldset>

			<br>
			<input class="w3-button dark-brown" type="submit" name="submit" value="Add Product">
		</form>

		<div class="w3-container cream">
			<?php
				function areFieldsMissing($requiredFields){
					foreach ($requiredFields as $field){
						if(!isset($_POST[$field]) || empty(trim($_POST[$field]))){
							return true;
						}
					}

					return false;
				}

				if(isset($_POST['submit'])){
					$fieldsToCheck = ['category_id', 'name', 'price', 'stock'];

					if(areFieldsMissing($fieldsToCheck)){
						echo "<div class='w3-pale-red w3-padding message-box'>";
						echo "You have not entered all the required details.<br>";
						echo "Please go back and try again.";
						echo "</div>";
						exit;
					}

					include "connectDatabase.php";

					$category_id = mysqli_real_escape_string($conn, $_POST['category_id']);
					$name = mysqli_real_escape_string($conn, $_POST['name']);
					$price = mysqli_real_escape_string($conn, $_POST['price']);
					$stock = mysqli_real_escape_string($conn, $_POST['stock']);

					$sql  = "INSERT INTO products (category_id, name, price, stock) ";
					$sql .= "VALUES('$category_id', '$name', '$price', '$stock') ";

					if($conn->query($sql) === TRUE){
						$product_id = $conn->insert_id;

						echo "<div class='w3-pale-green w3-padding message-box'>";
						echo "<strong>New product created successfully!</strong><br>";
						echo "Product ID: $product_id<br>";
						echo "Name: $name<br>";
						echo "Price: $$price<br>";
						echo "Stock: $stock<br>";
						echo "</div>";
					}
					else{
						echo "<div class='w3-pale-red w3-padding message-box'>";
						echo "Error: ".$sql."<br>".$conn->error;
						echo "</div>";
					}

					$conn->close();
				}
			?>
		</div>
	</div>
</body>
</html>